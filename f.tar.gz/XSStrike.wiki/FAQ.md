## Frequently Asked Questions

#### It says fuzzywuzzy is not installed but it is.
Well it's because XSStrike runs on python3 and you have to install the module with `pip3` as follows:

`pip3 install fuzzywuzzy`

#### What's up with Blind XSS?
Register on [xsshunter.com](https://xsshunter.com), copy your payload in `/core/config.py` within `blindPayload` variable. That's it.\
Then you can use the `--blind` option while crawling to make XSStrike inject your blind XSS payload in each parameter of each form.

> You can set up your own server and script instead of getting one from xsshunter.com but I recommend it because it's free, easy and open source.

#### Why XSStrike boasts that it is the most advanced XSS detection suite?
There are too many reasons, [take a look](https://github.com/s0md3v/XSStrike/wiki/Comparing-XSStrike-with-other-XSS-Scanners).

#### I like the project, what enhancements and features I can expect in future?
To see what is being worked on, check the [development board](https://github.com/s0md3v/XSStrike/projects/2) of XSStrike.
XSStrike will get the following updates in near future:
- ~Blind XSS~
- ~Proxy support~
- ~Verbose output toggle~
- ~Browser engine integration~
- Better detection mechanism
- Dynamic JS parsing for better DOM XSS scanning
- A dedicated filter bypassing engine
- Enhanced WAF evasion capabilities by WAF rules reversing
- XSStrike API
- XSStrike browser extension `in progress`
- XSStrike Burp Suite plugin `in progress`

### What's the false positive/negative rate?
There can be false positives while crawling because crawling skips thorough checks. If XSStrike marks a webpage as vulnerable while crawling, you should run a scan on that particular webpage for thorough scanning.

When you scan a single webpage, XSStrike makes use of a browser engine to ensure that the payload works and hence ensures zero false positives.

XSStrike already covers all the common + some special contexts but there can be false negatives if the injection requires some special strategy.

#### Tool `xyz` works against the target, while XSStrike doesn't!
Please use that other tool.

#### Can I copy it's code?
Yes, as long as you state changes and release your software under the same license. For more information, please read the license.
If you don't follow the conditions, you might get into trouble.

#### What if I want to embed it into a proprietary software?
You can mail me s0md3v@gmail.com to buy a license.