Welcome to XSStrike wiki!

## Compatibility & Dependencies
- [Python versions](https://github.com/s0md3v/XSStrike/wiki/Compatibility-&-Dependencies#python-versions)
- [Operating systems](https://github.com/s0md3v/XSStrike/wiki/Compatibility-&-Dependencies#operating-systems)
- [Colors](https://github.com/s0md3v/XSStrike/wiki/Compatibility-&-Dependencies#colors)
- [Dependencies](https://github.com/s0md3v/XSStrike/wiki/Compatibility-&-Dependencies#dependencies)

## Usage
- [Scan a single URL](https://github.com/s0md3v/XSStrike/wiki/Usage#scan-a-single-url)
- [Crawling](https://github.com/s0md3v/XSStrike/wiki/Usage#crawling)
- [Crawling depth](https://github.com/s0md3v/XSStrike/wiki/Usage#crawling-depth)
- [Testing/Crawling URLs from a file](https://github.com/s0md3v/XSStrike/wiki/Usage#testingcrawling-urls-from-a-file)
- [Number of threads](https://github.com/s0md3v/XSStrike/wiki/Usage#number-of-threads)
- [Timeout](https://github.com/s0md3v/XSStrike/wiki/Usage#timeout)
- [Delay](https://github.com/s0md3v/XSStrike/wiki/Usage#delay)
- [Payload Encoding](https://github.com/s0md3v/XSStrike/wiki/Usage#payload-encoding)
- [Bruteforce payloads from a file](https://github.com/s0md3v/XSStrike/wiki/Usage#bruteforce-payloads-from-a-file)
- [Blind XSS](https://github.com/s0md3v/XSStrike/wiki/Usage#blind-xss)
- [Supplying HTTP headers](https://github.com/s0md3v/XSStrike/wiki/Usage#supply-http-headers)
- [Fuzzing](https://github.com/s0md3v/XSStrike/wiki/Usage#fuzzing)
- [Using proxies](https://github.com/s0md3v/XSStrike/wiki/Usage#using-proxies)
- [Find hidden HTTP parameters](https://github.com/s0md3v/XSStrike/wiki/Usage#find-hidden-parameters)
- [Logging](https://github.com/s0md3v/XSStrike/wiki/Usage#logging)
- [Skip confirmation prompt](https://github.com/s0md3v/XSStrike/wiki/Usage#skip-confirmation-prompt)
- [Skip DOM scanning](https://github.com/s0md3v/XSStrike/wiki/Usage#skip-poc-generation)
- [Update](https://github.com/s0md3v/XSStrike/wiki/Usage#update)