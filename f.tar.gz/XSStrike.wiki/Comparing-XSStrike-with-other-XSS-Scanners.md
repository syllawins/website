### I brought the best one in each category

- **KNOXSS**: Best paid XSS scanner.
- **xsscrapy**: Best xss crawler because it uses context analysis to detect XSS.
- **Shuriken**: Best payload bruteforcer because it has a browser engine for zero false positive scanning.


| | KNOXSS | XSStrike | xsscrapy | Shuriken |
|-|--------|----------|---------|----------|
|Browser Extension|Yes|No|No|No|
|Free|No|Yes|Yes|Yes|
|Crawling|No|Yes|Yes|No|
|Blind XSS|Yes|Yes|No|No|
|DOM XSS|Yes|Yes|No|No|
|URL rewriting support|Yes|Yes|No|Yes|
|Sends your cookies to an external server|Yes|No|No|No|
|Context Analysis|Maybe|Yes|Yes|No|
|Parameter Discovery|Yes|Yes|No|No|
|Custom payloads|No|Yes|No|Yes|
|Supports payload encoding|No|Yes|No|No|
|JSON data support|No|Yes|No|No|
|Basic SQLi detection|Yes|No|Yes|No|
|Fuzzing support|No|Yes|No|No|
|WAF detection|No|Yes|No|No|
|Custom cookie support|Yes|Yes|Yes|No|
|Custom HTTP headers support|Yes|Yes|No|No|
|Proxy support|No|Yes|No|No|
|Customizable|No|Yes|Yes*|Yes*|
|Outdated JS libs scanning|No|Yes|No|No|
|Total Score|**8**|**17**|**7**|**4**|

### Performance

I tested the tools against [this](https://public-firing-range.appspot.com/) comprehensive XSS testbed and here are the results:

| | KNOXSS | XSStrike | xsscapy | Shuriken |
|-|--------|----------|---------|----------|
|[Reflected](https://public-firing-range.appspot.com/reflected/index.html)|34/48|37/48|34/48|-|
|[URL Based DOM](https://public-firing-range.appspot.com/urldom/index.html)|1/26|21/26|-|-|
|[DOM](https://public-firing-range.appspot.com/dom/)|1/44|44/44|-|-|
|[Address DOM](https://public-firing-range.appspot.com/address/index.html)|5/29|21/29|-|-|

```
Note: Shuriken is payload bruteforcer so it's success rate depends on the payload list supplied to so we aren't counting it and xsscrapy doesn't scan for DOM XSS.
```