A thorough explanation of different modules and the overall work flow.

> documentation is in progress, check back later

## Modules

### config.py

This file holds various variables that are used throughout the code.\
Here's a comprehensive list of all the variables:
- **changes:** It contains the changelog to be displayed when a user checks for update.
- **xsschecker:** This non malicious string is used as a probe to detect reflection contexts.
- **proxies:** Proxies to be used
- **minEfficiency:** Payloads with efficiency lower than this value will not be displayed to the user.
- **delay:** Default delay between requests.
- **threadCount:** Default number of threads.
- **timeout:** Default HTTP request timeout.
- **specialAttributes:** HTML tag attributes that need to be treated specially because of their nature.
- **badTags:** HTML tags which need to be broken out of as the code within them is not evaluated by browsers.
- **tags:** Tags to be used while generating payloads.
- **jsFillings:** Characters that can be used around a JS function call without breaking the syntax.
- **lFillings:** Characters that can be used before `>` in a HTML tag.
- **eFillings:** Characters that can be used between = and JavaScript function or event handler.
- **fillings:** Strings that can be used instead of space
- **eventHandlers:** Event handlers and the tags compatible with them to be used while generating payloads
- **functions:** JavaScript functions that serve as POC of the payload
- **payloads:** Payloads for filter and WAF evasion
- **fuzzes:** Strings to be sent while fuzzing a target
- **headers:** Default headers to be sent
- **blindParams:** List of common parameter names for parameter discovery

### colors.py
It contains ANSI escape sequences which produce colored output.

### requester.py
XSStrike makes all the HTTP requests with this module. It accepts following self explanatory parameters:\
`url`, `data`, `headers`, `GET`, `delay`, `timeout`

### htmlParser.py
It parses the response of the target webpage and figures out the following things:
- **Context:** Contexts where the input is getting reflected. It can be `html`, `attribute`, `script` or `comment`
- **Breaker:** Breaker is the term given to a string which should be used for breaking out of the context.
- **Attribute:** The attribute name in case of `attribute` context.
- **Tag** The tag name in case of `attribute` context.

### jsContexter.py
It is a javascript parser which returns a string which can be used to break out of the context.

### checker.py
Whenever XSStrike needs to inject a string and observe the response, this module is called.
It stores the positions of the reflections when first contact is made to the target for parsing and then uses those positions to locate the reflections in all the injections afterwards.
The injected string and the reflected strings are compared by using [Levenshtein distance](https://en.wikipedia.org/wiki/Levenshtein_distance) and it returns how much similar both strings are. The value ranges from 0-100 and is called efficiency of the injected string i.e. payload.

### filterChecker.py
It checks all the special characters to be used while generating a payload to see if they are getting escaped or not. It uses `checker.py` for this purpose.

### generator.py
This is the payload engine, it analyses the information returned by `htmlParser.py` and `filterChecker.py` to see if any payload scheme can work in those conditions.\
It should be noted that, it assign an attribute named `confidence` to each payload group which represents how much confidence developer has on that payload group. It varies from 0-10, higher the better.

### wafDetector.py
As the name suggests, it detects most common WAFs by comparing headers, status code and response against signatures defined in `/db/wafSignatures.json`.

### utils.py
It is a collection of small utility functions that are used throughout the code.
- **closest:** It accepts a number and a list of numbers, and then returns a number from that list which is closest to the provided number.
- **fillHoles:** It accepts two lists containing numbers and combines them to form a new list where the elements are arranged in ascending order.
- **randomUpper:** Converts random alphabets in a string to uppercase.
- **genGen:** Generates payload for HTML context. It's been placed in `utils.py` since it's been used more than one time in `generator.py`.

### zetanize.py
It parses a html document (response) to extract html forms.

### photon.py
It recursively crawls the website using the input URL as seeds and sends the response returned to `zetanize.py` for extracting the forms and once the crawling is finished, it returns all the extracted forms.

### prompt.py
It opens your favorite text editor (default: `nano`) and let's you paste your HTTP headers in there for using with XSStrike.

### dom.py
It finds potentially vulnerable sources and sinks with regular expressions.
I will be improved in near future.

### fuzzer.py
It sends "not-so-malicious" strings defined in `config.py` with random delays to see what's being blocked by the WAF and what isn't.

### updater.py
`config.py` contains a variable named `changes` which contains changelog of the current build. When updater is called, it compares local and github copy of `config.py`, if the value of `changes` variable is different, user is prompted for update.

### arjun.py
It makes requests to the webpage with common parameter names defined in `config.py`, if value of the parameter reflected into the webpage, it is used for further testing

### log.py
It allows to get a new logger instance by using the `setup_logger` function. The logger is configured according to the arguments that xsstrike has received on startup and stored in `console_log_level`, `file_log_level` and `log_file` vars and will use a formatter to automatically prepend the required prefix depending on the created log record level. Additionally, the logger instance has  `RUN`, `GOOD` and `VULN` custom logging levels and the following available methods:

- **no_format**: Creates a new log record without automatically adding any prefix. Log level can be specified through the `level` parameter whose default value is `INFO`

- **debug_json**: Converts the received dict to json and appends it to the end of the new log record which is always created with `DEBUG` level.

- **red_line**: Creates a red line which can be used as separator. Amount of `-` characters and log level can be specified through `amount` and `level` paramets.  


## Workflow
### Testing a webpage
- Start with the first parameter and it's replace its value with `xsschecker` defined in `config.py`.
- Make a request with this data using `requester.py` and feed the response to `dom.py` which uses regular expression to find potentially vulnerable sources and sinks.
- The same response is then feeded to`htmlParser.py` which returns context information.
- Supply the context information to `filterChecker.py` which sends all the character required for generating payloads to `checker.py` one by one.
- `checker.py` makes request to the target with the strings given by `filterChecker.py` and returns `efficiency` by comparing injected and reflected string.
- This efficiency information is added to the context information and is sent to `generator.py` which evaluates it and generates payloads if possible.
- `generator.py` returns payloads ordered by `confidence`.
- Payloads with higher `confidence` value are tried first. They are sent one by one to `checker.py` which again returns the `efficiency` of each injected payload. 
- If the `efficiency` is greater than `minEfficiency` defined in `config.py`, the payload is marked as successful and displayed to the user.